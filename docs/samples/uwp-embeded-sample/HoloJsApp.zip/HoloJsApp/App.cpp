﻿#include "pch.h"
#include "App.h"

// The main function is only used to initialize our IFrameworkView class.
[Platform::MTAThread]
int main(Platform::Array<Platform::String^>^)
{
	// Create a host object
	auto scriptHost = ref new HoloJs::UWP::HoloJsScriptHost();

	// Create a default configuration
	auto viewConfiguration = ref new HoloJs::UWP::ViewConfiguration();

	// Initialize and run
	if (scriptHost->initialize(viewConfiguration)) {
		auto uri = ref new Platform::String(L"holojs-app\\holojs-app.json");
		scriptHost->startUri(uri);
	}
	return 0;
}

